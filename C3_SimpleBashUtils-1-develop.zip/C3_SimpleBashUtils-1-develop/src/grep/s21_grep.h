#ifndef SRC_GREP_S21_GREP_H_
#define SRC_GREP_S21_GREP_H_

#include <getopt.h>
#include <regex.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFFSIZE 8192

static char observable_string[BUFFSIZE] = {0};

void check_flags(int argc, char* argv[]);
void open_file(int argc, char* argv[]);
void flag_e();
void flag_f();

void find_and_print(char* argv[], FILE* file);

struct characteristics {
  int lines_count;
  int files_count;
  int empty_lines;
  int e_count;
} characteristics;

struct option flags[] = {
    {"e", no_argument, 0, 'e'}, {"i", no_argument, 0, 'i'},
    {"v", no_argument, 0, 'v'}, {"c", no_argument, 0, 'c'},
    {"l", no_argument, 0, 'l'}, {"n", no_argument, 0, 'n'},
    {"h", no_argument, 0, 'h'}, {"s", no_argument, 0, 's'},
    {"f", no_argument, 0, 'f'}, {"o", no_argument, 0, 'o'},
};

struct flag {
  int e;
  int i;
  int v;
  int c;
  int l;
  int n;
  int h;
  int s;

  int f;
  int o;
  int any_flags;
} flag;

void init_options() {
  flag.e = 0;
  flag.i = 0;
  flag.v = 0;
  flag.c = 0;
  flag.l = 0;
  flag.n = 0;
  flag.h = 0;
  flag.s = 0;
  flag.f = 0;
  flag.o = 0;

  characteristics.lines_count = 0;
  characteristics.files_count = 0;
  characteristics.empty_lines = 0;
  characteristics.e_count = 0;
}

#endif
